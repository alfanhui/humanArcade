# humanArcade
Raspberry pi python program to take ps4 controlls and output voice commands to bluetooth headset
